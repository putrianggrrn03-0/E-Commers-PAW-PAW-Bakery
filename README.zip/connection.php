<?php
$serverName = "localhost";
$username= "root";
$password="";
$db = "pawdb";
$conn = mysqli_connect($serverName, $username, $password, $db);


// if (!$conn){
//     echo "eror";
// }
// else{
//     echo "terhubung";
// }   